create table users
(
  name char(50) not null ,
  email char(50) primary key,
  password char(30) not null
);





