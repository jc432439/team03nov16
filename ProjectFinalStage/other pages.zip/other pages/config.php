<?php
//define constants for connection info
define("MYSQLUSER","jc454472");
define("MYSQLPASS","As34704011Sa");
define("HOSTNAME","localhost");
define("MYSQLDB","jc454472");

//make connection to database
function db_connect()
{
	$conn = @new mysqli(HOSTNAME, MYSQLUSER, MYSQLPASS, MYSQLDB);
	if($conn -> connect_error) {
		die('Connect Error: ' . $conn -> connect_error);
	}
	return $conn;
} 
?>

